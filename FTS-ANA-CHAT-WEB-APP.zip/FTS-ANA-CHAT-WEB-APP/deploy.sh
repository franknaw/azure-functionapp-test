cd chatWidget
rm app.zip
zip -r app.zip *
az webapp deploy --resource-group "FSC-DEVTEST-INT-SOUTH-FTS-ANA-RG" --name "SOUTHFTS-APP-ANA-CHAT" --src-path "./app.zip"