
  516  npx express-generator myExpressApp --view ejs
 517  cd myExpressApp && npm install
  518  npm audit fix --force

