

// require('dotenv')

require('dotenv').config({ path: './.env' })

const apimKey = process.env.APIMKEY;
module.exports = { apimKey };