/**
 * AI Chatbot Widget
 * A vanilla JavaScript chatbot that can be added to any website
 * Fixed version with improved UI rendering and new conversation functionality
 */

(function () {
    // Main widget class
    class ChatbotWidget {
        constructor(options = {}) {
            this.options = Object.assign({
                title: 'AI Anna',
                initialMessage: "Hello! I'm Anna. How can I help you today?",
                position: 'bottom-right',
                primaryColor: '#1E74FD',
                darkBlue: '#002B5C',
                greenColor: '#4CAF50',
                redColor: '#F44336',
                timeZone: 'EST', // Default timezone for displaying conversation start time
            }, options);

            this.isOpen = false;
            this.conversations = [
                {
                    id: this.generateId(),
                    title: 'New Conversation',
                    startTime: this.getCurrentTime(),
                    startDate: this.getCurrentDate(),
                    messages: [
                        {
                            sender: 'bot',
                            text: this.options.initialMessage,
                            time: this.getCurrentTime(),
                            date: this.getCurrentDate(),
                            feedback: null
                        }
                    ]
                },
                {
                    id: this.generateId(),
                    title: 'Vendor Payment',
                    startTime: "09:15 AM",
                    startDate: "Feb 25, 2025",
                    messages: [
                        {
                            sender: 'bot',
                            text: "I see you're having an issue with vendor payment processing. How can I help?",
                            time: "09:15 AM",
                            date: "Feb 25, 2025",
                            feedback: 'positive'
                        },
                        {
                            sender: 'user',
                            text: "I'm getting an error when trying to process payment for vendor XYZ Corp.",
                            time: "09:16 AM",
                            date: "Feb 25, 2025",
                            feedback: null
                        },
                        {
                            sender: 'bot',
                            text: "I'll help you resolve this. Can you provide the vendor ID and the error message you're seeing?",
                            time: "09:16 AM",
                            date: "Feb 25, 2025",
                            feedback: 'positive'
                        }
                    ]
                },
                {
                    id: this.generateId(),
                    title: 'Transaction: Status update on LIE',
                    startTime: "08:45 AM",
                    startDate: "Feb 25, 2025",
                    messages: [
                        {
                            sender: 'bot',
                            text: "You'd like to check on the status of a LIE transaction. I can help with that.",
                            time: "08:45 AM",
                            date: "Feb 25, 2025",
                            feedback: null
                        },
                        {
                            sender: 'user',
                            text: "Yes, I need to know the current status of LIE-239087.",
                            time: "08:46 AM",
                            date: "Feb 25, 2025",
                            feedback: null
                        },
                        {
                            sender: 'bot',
                            text: "I've checked the status of LIE-239087. It's currently in 'Pending Approval' status waiting for manager review.",
                            time: "08:47 AM",
                            date: "Feb 25, 2025",
                            feedback: 'positive'
                        }
                    ]
                },
                {
                    id: this.generateId(),
                    title: 'Order OPE-56789 was rej...',
                    startTime: "10:22 AM",
                    startDate: "Feb 25, 2025",
                    messages: [
                        {
                            sender: 'bot',
                            text: "I understand you're having an issue with a rejected OPE order. Let me help you resolve this.",
                            time: "10:22 AM",
                            date: "Feb 25, 2025",
                            feedback: null
                        },
                        {
                            sender: 'user',
                            text: "Order OPE-56789 was rejected but I don't understand the reason given.",
                            time: "10:23 AM",
                            date: "Feb 25, 2025",
                            feedback: null
                        },
                        {
                            sender: 'bot',
                            text: "I've reviewed order OPE-56789. It was rejected because of a missing required field: the delivery date. Once you add this, you can resubmit the order.",
                            time: "10:24 AM",
                            date: "Feb 25, 2025",
                            feedback: 'positive'
                        }
                    ]
                },
                {
                    id: this.generateId(),
                    title: 'Adding GSA OA Numbers to DB',
                    startTime: "11:05 AM",
                    startDate: "Feb 25, 2025",
                    messages: [
                        {
                            sender: 'bot',
                            text: "You need help adding GSA OA numbers to the database? I can guide you through the process.",
                            time: "11:05 AM",
                            date: "Feb 25, 2025",
                            feedback: null
                        },
                        {
                            sender: 'user',
                            text: "Yes, I have a list of new GSA OA numbers that need to be added to our system.",
                            time: "11:06 AM",
                            date: "Feb 25, 2025",
                            feedback: null
                        },
                        {
                            sender: 'bot',
                            text: "Great. To add GSA OA numbers, you'll need to go to the Admin Portal > Database Management > GSA Records. From there, you can either upload a CSV file or add them individually using the 'Add New' button.",
                            time: "11:07 AM",
                            date: "Feb 25, 2025",
                            feedback: 'positive'
                        },
                        {
                            sender: 'user',
                            text: "What format should the CSV file be in?",
                            time: "11:08 AM",
                            date: "Feb 25, 2025",
                            feedback: null
                        },
                        {
                            sender: 'bot',
                            text: "The CSV should have these columns: OA_Number, Issue_Date, Expiration_Date, Agency_ID, and Status. You can download a template from the upload page by clicking 'Download Template'.",
                            time: "11:09 AM",
                            date: "Feb 25, 2025",
                            feedback: 'positive'
                        }
                    ]
                }
            ];
            this.activeConversationId = this.conversations[0].id;

            this.init();
        }

        generateId() {
            return 'conv-' + Math.random().toString(36).substr(2, 9);
        }

        getCurrentTime() {
            const now = new Date();
            let hours = now.getHours();
            const minutes = now.getMinutes();
            const ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12;
            hours = hours ? hours : 12;
            const minutesStr = minutes < 10 ? '0' + minutes : minutes;
            return `${hours}:${minutesStr} ${ampm}`;
        }

        getCurrentDate() {
            const now = new Date();
            const month = now.toLocaleString('default', {month: 'short'});
            const day = now.getDate();
            const year = now.getFullYear();
            return `${month} ${day}, ${year}`;
        }

        truncateText(text, length = 10) {
            return text.length > length ? text.substring(0, length) + '...' : text;
        }

        init() {
            this.createStyles();
            this.createWidgetButton();
            this.createChatWindow();
            this.bindEvents();
            this.handleResize();

            // Add resize event listener
            window.addEventListener('resize', this.handleResize.bind(this));
        }

        // Handle window resize
        handleResize() {
            if (window.innerWidth < 480) {
                // Mobile adjustments
                if (this.chatWindow) {
                    this.chatWindow.style.width = '100%';
                    this.chatWindow.style.height = '100%';
                    this.chatWindow.style.bottom = '0';
                    this.chatWindow.style.right = '0';
                    this.chatWindow.style.borderRadius = '0';
                }

                if (this.widgetButton) {
                    this.widgetButton.style.width = '52px';
                    this.widgetButton.style.height = '52px';
                    this.widgetButton.style.borderRadius = '50%';
                    this.widgetButton.style.justifyContent = 'center';
                    this.widgetButton.style.right = '20px';

                    // Hide text, only show icon
                    const buttonText = this.widgetButton.querySelector('.ai-chatbot-button-text');
                    if (buttonText) buttonText.style.display = 'none';

                    const buttonIcon = this.widgetButton.querySelector('.ai-chatbot-button-icon');
                    if (buttonIcon) buttonIcon.style.marginRight = '0';
                }
            } else {
                // Reset to desktop
                if (this.chatWindow) {
                    this.chatWindow.style.width = '360px';
                    this.chatWindow.style.height = '580px';
                    this.chatWindow.style.bottom = '90px';
                    this.chatWindow.style.right = '20px';
                    this.chatWindow.style.borderRadius = '12px';
                }

                if (this.widgetButton) {
                    this.widgetButton.style.width = '190px';
                    this.widgetButton.style.height = '48px';
                    this.widgetButton.style.borderRadius = '24px';
                    this.widgetButton.style.justifyContent = 'flex-start';
                    this.widgetButton.style.right = '20px';

                    // Show text again
                    const buttonText = this.widgetButton.querySelector('.ai-chatbot-button-text');
                    if (buttonText) buttonText.style.display = 'block';

                    const buttonIcon = this.widgetButton.querySelector('.ai-chatbot-button-icon');
                    if (buttonIcon) buttonIcon.style.marginRight = '10px';
                }
            }
        }

        createStyles() {
            const style = document.createElement('style');
            style.textContent = `
          .ai-chatbot-widget * {
            box-sizing: border-box;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
          }
          
          .ai-chatbot-button {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 190px;
            height: 48px;
            border-radius: 24px;
            background-color: ${this.options.darkBlue};
            color: white;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            padding: 0 16px;
            cursor: pointer;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            z-index: 9999;
            transition: all 0.3s ease;
          }
          
          .ai-chatbot-button:hover {
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.25);
          }
          
          .ai-chatbot-button-icon {
            width: 20px;
            height: 20px;
            margin-right: 10px;
            fill: white;
          }
          
          .ai-chatbot-button-text {
            font-size: 14px;
            font-weight: 500;
          }
          
          .ai-chatbot-window {
            position: fixed;
            bottom: 90px;
            right: 20px;
            width: 360px;
            height: 580px;
            max-height: 80vh;
            border-radius: 12px;
            background-color: white;
            display: flex;
            flex-direction: column;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            z-index: 9999;
            opacity: 0;
            transform: translateY(20px) scale(0.95);
            pointer-events: none;
            transition: all 0.3s ease;
            overflow: hidden;
            border: 1px solid #E5E5E5;
          }
          
          .ai-chatbot-window.open {
            opacity: 1;
            transform: translateY(0) scale(1);
            pointer-events: all;
          }
          
          .ai-chatbot-button.hidden {
            opacity: 0;
            transform: scale(0.8);
            pointer-events: none;
          }
          
          .ai-chatbot-header {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-bottom: 1px solid #E5E5E5;
            background-color: #FFFFFF;
            transition: background-color 0.3s ease;
          }
          
          .ai-chatbot-conversation-info {
            display: flex;
            flex-direction: column;
            flex: 1;
          }
          
          .ai-chatbot-dropdown {
            position: relative;
            margin-right: 10px;
          }
          
          .ai-chatbot-dropdown-button {
            color: ${this.options.primaryColor};
            font-weight: 600;
            font-size: 15px;
            display: flex;
            align-items: center;
            cursor: pointer;
          }
          
          .ai-chatbot-dropdown-button svg {
            margin-left: 5px;
            width: 10px;
            height: 10px;
            fill: ${this.options.primaryColor};
          }
          
          .ai-chatbot-conversation-time {
            font-size: 11px;
            color: #999;
            margin-top: 2px;
          }
          
          .ai-chatbot-dropdown-content {
            position: absolute;
            top: 100%;
            left: 0;
            background: white;
            min-width: 240px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
            z-index: 1;
            border-radius: 8px;
            display: none;
            flex-direction: column;
            max-height: 350px;
            overflow-y: auto;
            border: 1px solid #E5E5E5;
            opacity: 0;
            transform: translateY(-10px);
            transition: opacity 0.2s ease, transform 0.2s ease;
          }
          
          .ai-chatbot-dropdown-content.open {
            display: flex;
            opacity: 1;
            transform: translateY(0);
          }
          
          .ai-chatbot-dropdown-item {
            display: flex;
            flex-direction: column;
            padding: 10px 15px;
            cursor: pointer;
            border-bottom: 1px solid #f1f1f1;
            transition: background-color 0.2s ease;
          }
          
          .ai-chatbot-dropdown-item:hover {
            background-color: #F8F9FA;
          }
          
          .ai-chatbot-dropdown-title {
            font-weight: 600;
            color: #000;
            margin-bottom: 3px;
          }
          
          .ai-chatbot-dropdown-subtitle {
            font-size: 12px;
            color: #666;
          }
          
          .ai-chatbot-dropdown-time {
            font-size: 10px;
            color: #999;
            margin-top: 3px;
          }
          
          .ai-new-conversation {
            padding: 12px 15px;
            font-weight: 600;
            color: ${this.options.primaryColor};
            display: flex;
            align-items: center;
            cursor: pointer;
            transition: background-color 0.2s ease;
          }
          
          .ai-new-conversation:hover {
            background-color: #F8F9FA;
          }
          
          .ai-new-conversation:active {
            background-color: #EEF3FF;
          }
          
          .ai-new-conversation svg {
            margin-right: 5px;
            width: 14px;
            height: 14px;
            fill: ${this.options.primaryColor};
          }
          
          .ai-chatbot-help {
            margin-left: 10px;
            cursor: pointer;
            width: 18px;
            height: 18px;
            opacity: 0.5;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background-color: #F0F0F0;
            color: #666;
            font-size: 12px;
            font-weight: bold;
            transition: opacity 0.2s;
          }
          
          .ai-chatbot-help:hover {
            opacity: 1;
          }
          
          .ai-chatbot-help-tooltip {
            position: absolute;
            top: 45px;
            right: 20px;
            background-color: #333;
            color: white;
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 12px;
            width: 280px;
            z-index: 10;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s, visibility 0.3s;
          }
          
          .ai-chatbot-help-tooltip.visible {
            opacity: 1;
            visibility: visible;
          }
          
          .ai-chatbot-help-tooltip:after {
            content: "";
            position: absolute;
            bottom: 100%;
            right: 10px;
            border-width: 5px;
            border-style: solid;
            border-color: transparent transparent #333 transparent;
          }
          
          .ai-chatbot-close {
            margin-left: 10px;
            cursor: pointer;
            width: 18px;
            height: 18px;
            opacity: 0.5;
            transition: opacity 0.2s;
          }
          
          .ai-chatbot-close:hover {
            opacity: 1;
          }
          
          .ai-chatbot-body {
            flex: 1;
            overflow-y: auto;
            padding: 15px;
            background-color: #F8F9FA;
            scroll-behavior: smooth;
          }
          
          .ai-chatbot-message {
            display: flex;
            margin-bottom: 12px;
            flex-direction: column;
            position: relative;
            transition: transform 0.2s ease;
            width: 100%;
          }
          
          .ai-chatbot-message-content {
            max-width: 85%;
            padding: 10px 14px;
            border-radius: 16px;
            margin-bottom: 3px;
            word-break: break-word;
            line-height: 1.4;
            position: relative;
            font-size: 14px;
          }
          
          .ai-chatbot-message.bot .ai-chatbot-message-content {
            background-color: #FFFFFF;
            color: #000;
            border: 1px solid #E9E9E9;
            margin-right: auto;
            border-top-left-radius: 4px;
          }
  
          .ai-chatbot-message.bot {
            padding-left: 36px;
            position: relative;
          }
  
          .ai-chatbot-avatar {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            background-color: #F0F3FF;
            display: flex;
            align-items: center;
            justify-content: center;
            color: ${this.options.primaryColor};
            font-weight: bold;
            position: absolute;
            left: 0;
            top: 0;
            font-size: 12px;
          }
          
          .ai-chatbot-message.user .ai-chatbot-message-content {
            background-color: ${this.options.primaryColor};
            color: white;
            margin-left: auto;
            border-top-right-radius: 4px;
          }
          
          .ai-chatbot-message-time {
            font-size: 11px;
            color: #999;
            margin-top: 2px;
            display: flex;
            align-items: center;
          }
          
          .ai-chatbot-message.bot .ai-chatbot-message-time {
            margin-left: 5px;
          }
          
          .ai-chatbot-message.user .ai-chatbot-message-time {
            margin-right: 5px;
            align-self: flex-end;
          }
          
          /* Updated feedback buttons style with improved thumbs icons */
          .ai-chatbot-feedback {
            position: absolute;
            right: -10px;
            top: -8px;
            display: flex;
            opacity: 0;
            transition: opacity 0.3s ease;
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 24px;
            padding: 4px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
            z-index: 5;
          }
          
          .ai-chatbot-message-content:hover .ai-chatbot-feedback {
            opacity: 1;
          }
          
          .ai-chatbot-feedback-button {
            background: none;
            border: 1px solid #CCCCCC;
            cursor: pointer;
            transition: all 0.2s ease;
            margin: 0 2px;
            width: 28px;
            height: 28px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            color: #CCCCCC;
            position: relative;
          }
          
          .ai-chatbot-feedback-button:hover {
            transform: scale(1.1);
          }
          
          .ai-chatbot-feedback-button.positive.active {
            background-color: ${this.options.greenColor};
            border-color: ${this.options.greenColor};
            color: white;
          }
          
          .ai-chatbot-feedback-button.negative.active {
            background-color: ${this.options.redColor};
            border-color: ${this.options.redColor};
            color: white;
          }
          
          .ai-chatbot-feedback-button svg {
            width: 16px;
            height: 16px;
            fill: currentColor;
            stroke: currentColor;
          }
          
          .ai-chatbot-footer {
            padding: 10px 15px;
            border-top: 1px solid #E5E5E5;
            background-color: #FFFFFF;
          }
          
          .ai-chatbot-input-container {
            display: flex;
            align-items: center;
            border: 1px solid #E5E5E5;
            border-radius: 20px;
            padding: 6px 12px;
            background-color: #F8F9FA;
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
          }
          
          .ai-chatbot-input-container:focus-within {
            border-color: #D0D0D0;
            box-shadow: 0 0 0 2px rgba(30, 116, 253, 0.1);
          }
          
          .ai-chatbot-input {
            flex: 1;
            border: none;
            outline: none;
            background: transparent;
            font-size: 14px;
            padding: 5px 0;
            color: #333;
          }
          
          .ai-chatbot-input::placeholder {
            color: #999;
          }
          
          .ai-chatbot-send {
            background-color: ${this.options.primaryColor};
            border: none;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            margin-left: 8px;
            transition: background-color 0.2s ease, transform 0.2s ease;
          }
          
          .ai-chatbot-send:hover {
            background-color: #0D5EDF;
            transform: scale(1.05);
          }
          
          .ai-chatbot-send:active {
            transform: scale(0.95);
          }
          
          .ai-chatbot-send svg {
            width: 15px;
            height: 15px;
            fill: white;
          }
  
          @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
          }
          
          @keyframes fadeOut {
            from { opacity: 1; }
            to { opacity: 0; }
          }
          
          @keyframes slideIn {
            from { transform: translateY(10px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
          }
  
          .fade-in {
            animation: fadeIn 0.3s ease forwards;
          }
          
          .fade-out {
            animation: fadeOut 0.3s ease forwards;
          }
          
          .slide-in {
            animation: slideIn 0.3s ease forwards;
          }
          
          .ai-chatbot-message.new-message {
            animation: slideIn 0.3s ease forwards;
          }
        `;
            document.head.appendChild(style);
        }

        createWidgetButton() {
            const button = document.createElement('div');
            button.className = 'ai-chatbot-widget ai-chatbot-button';
            button.innerHTML = `
          <svg class="ai-chatbot-button-icon" viewBox="0 0 24 24" xmlns=http://www.w3.org/2000/svg>
            <path d="M20 2H4C2.9 2 2 2.9 2 4V22L6 18H20C21.1 18 22 17.1 22 16V4C22 2.9 21.1 2 20 2ZM20 16H6L4 18V4H20V16Z"/>
          </svg>
          <span class="ai-chatbot-button-text">Chat with Anna</span>
        `;
            document.body.appendChild(button);
            this.widgetButton = button;
        }

        createChatWindow() {
            const chatWindow = document.createElement('div');
            chatWindow.className = 'ai-chatbot-widget ai-chatbot-window';

            // Get active conversation for header info
            const activeConversation = this.getActiveConversation();

            chatWindow.innerHTML = `
          <div class="ai-chatbot-header">
            <div class="ai-chatbot-conversation-info">
              <div class="ai-chatbot-dropdown">
                <div class="ai-chatbot-dropdown-button">
                  ${activeConversation ? activeConversation.title : this.options.title}
                  <svg viewBox="0 0 24 24" xmlns=http://www.w3.org/2000/svg>
                    <path d="M7 10l5 5 5-5z"/>
                  </svg>
                </div>
                <div class="ai-chatbot-dropdown-content">
                  <div class="ai-new-conversation">
                    <svg viewBox="0 0 24 24" xmlns=http://www.w3.org/2000/svg>
                      <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>
                    </svg>
                    New Conversation
                  </div>
                  ${this.renderConversationItems()}
                </div>
              </div>
              <div class="ai-chatbot-conversation-time">
                Conversation started ${activeConversation ? activeConversation.startTime : this.getCurrentTime()} ${this.options.timeZone} | ${activeConversation ? activeConversation.startDate : this.getCurrentDate()}
              </div>
            </div>
            <div class="ai-chatbot-help">?</div>
            <div class="ai-chatbot-help-tooltip">This is a chatbot, please check all responses. It can make up information.</div>
            <div class="ai-chatbot-close">
              <svg viewBox="0 0 24 24" xmlns=http://www.w3.org/2000/svg>
                <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
              </svg>
            </div>
          </div>
          <div class="ai-chatbot-body">
            ${this.renderMessages()}
          </div>
          <div class="ai-chatbot-footer">
            <div class="ai-chatbot-input-container">
              <input type="text" class="ai-chatbot-input" placeholder="Type your message here...">
              <button class="ai-chatbot-send">
                <svg viewBox="0 0 24 24" xmlns=http://www.w3.org/2000/svg>
                  <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
                </svg>
              </button>
            </div>
          </div>
        `;
            document.body.appendChild(chatWindow);
            this.chatWindow = chatWindow;

            // Get elements
            this.conversationInfo = chatWindow.querySelector('.ai-chatbot-conversation-info');
            this.dropdownButton = chatWindow.querySelector('.ai-chatbot-dropdown-button');
            this.dropdownContent = chatWindow.querySelector('.ai-chatbot-dropdown-content');
            this.conversationTime = chatWindow.querySelector('.ai-chatbot-conversation-time');
            this.helpButton = chatWindow.querySelector('.ai-chatbot-help');
            this.helpTooltip = chatWindow.querySelector('.ai-chatbot-help-tooltip');
            this.closeButton = chatWindow.querySelector('.ai-chatbot-close');
            this.messageInput = chatWindow.querySelector('.ai-chatbot-input');
            this.sendButton = chatWindow.querySelector('.ai-chatbot-send');
            this.chatBody = chatWindow.querySelector('.ai-chatbot-body');
            this.newConversationButton = chatWindow.querySelector('.ai-new-conversation');
        }

        renderConversationItems() {
            return this.conversations.map(conv => `
          <div class="ai-chatbot-dropdown-item" data-id="${conv.id}">
            <div class="ai-chatbot-dropdown-title">${conv.title}</div>
            <div class="ai-chatbot-dropdown-subtitle">${conv.messages.length > 0 ? this.truncateText(conv.messages[0].text, 30) : 'Start a new conversation'}</div>
            <div class="ai-chatbot-dropdown-time">Started ${conv.startTime} ${this.options.timeZone} | ${conv.startDate}</div>
          </div>
        `).join('');
        }

        renderMessages() {
            const activeConversation = this.getActiveConversation();
            if (!activeConversation) return '';

            return activeConversation.messages.map(msg => {
                // Determine if feedback exists
                const hasFeedback = msg.feedback !== null;

                return `
            <div class="ai-chatbot-message ${msg.sender}">
              ${msg.sender === 'bot' ? `<div class="ai-chatbot-avatar">AI</div>` : ''}
              <div class="ai-chatbot-message-content">
                ${msg.text}
                ${msg.sender === 'bot' ? `
                  <div class="ai-chatbot-feedback">
                    <button class="ai-chatbot-feedback-button positive ${msg.feedback === 'positive' ? 'active' : ''}" data-index="${activeConversation.messages.indexOf(msg)}">
                      <svg viewBox="0 0 24 24" xmlns=http://www.w3.org/2000/svg>
                        <path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z"/>
                      </svg>
                    </button>
                    <button class="ai-chatbot-feedback-button negative ${msg.feedback === 'negative' ? 'active' : ''}" data-index="${activeConversation.messages.indexOf(msg)}">
                      <svg viewBox="0 0 24 24" xmlns=http://www.w3.org/2000/svg>
                        <path d="M15 3H6c-.83 0-1.54.5-1.84 1.22l-3.02 7.05c-.09.23-.14.47-.14.73v2c0 1.1.9 2 2 2h6.31l-.95 4.57-.03.32c0 .41.17.79.44 1.06L9.83 23l6.59-6.59c.36-.36.58-.86.58-1.41V5c0-1.1-.9-2-2-2zm4 0v12h4V3h-4z"/>
                      </svg>
                    </button>
                  </div>
                ` : ''}
              </div>
              <div class="ai-chatbot-message-time">
                ${msg.time} | ${msg.date}
              </div>
            </div>
          `;
            }).join('');
        }

        getActiveConversation() {
            return this.conversations.find(conv => conv.id === this.activeConversationId);
        }

        getResponse = async (query) => {
            try {
                const response = await fetch(`https://fts-ana-api.azure-api.us/SOUTHFTS-FUNC-ANA-CHAT/rag-chat`, {
                    method: 'POST',
                    headers: {
                        'Ocp-Apim-Subscription-Key': apimKey,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({query: query})
                });
                if (!response.ok) {
                    const errorDetails = await response.text();
                    return `Network response was not ok: ${errorDetails}`;
                }

                const data = await response.json();
                return data.chat_response

            } catch (error) {
                console.error('There was a problem with the fetch operation:', error);
                return error
            }
        };

        updateDropdownContent() {
            this.dropdownContent.innerHTML = `
          <div class="ai-new-conversation">
            <svg viewBox="0 0 24 24" xmlns=http://www.w3.org/2000/svg>
              <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>
            </svg>
            New Conversation
          </div>
          ${this.renderConversationItems()}
        `;

            // Re-bind events
            this.bindDropdownItemEvents();
            this.bindNewConversationEvent();

            // Update active conversation title and time in header
            const activeConversation = this.getActiveConversation();
            if (activeConversation) {
                this.dropdownButton.innerHTML = `
            ${activeConversation.title}
            <svg viewBox="0 0 24 24" xmlns=http://www.w3.org/2000/svg>
              <path d="M7 10l5 5 5-5z"/>
            </svg>
          `;

                // Update conversation start time
                if (this.conversationTime) {
                    this.conversationTime.textContent = `Conversation started ${activeConversation.startTime} ${this.options.timeZone} | ${activeConversation.startDate}`;
                }
            }
        }

        updateMessages() {
            this.chatBody.innerHTML = this.renderMessages();
            this.scrollToBottom();
            this.bindFeedbackEvents();
        }

        scrollToBottom() {
            setTimeout(() => {
                this.chatBody.scrollTop = this.chatBody.scrollHeight;
            }, 50); // Faster scroll for better responsiveness
        }

        toggleChatWindow() {
            this.isOpen = !this.isOpen;
            if (this.isOpen) {
                // Show chat window with animation
                this.chatWindow.classList.add('open');
                // Hide button with animation
                this.widgetButton.classList.add('hidden');
                setTimeout(() => {
                    this.messageInput.focus();
                }, 300);
                this.scrollToBottom();
            } else {
                // Hide chat window with animation
                this.chatWindow.classList.remove('open');
                this.dropdownContent.classList.remove('open');
                this.helpTooltip.classList.remove('visible');
                // Show button with animation after a slight delay
                setTimeout(() => {
                    this.widgetButton.classList.remove('hidden');
                }, 150);
            }
        }

        toggleDropdown() {
            // Force render before toggling to ensure proper display
            setTimeout(() => {
                this.dropdownContent.classList.toggle('open');

                // If opening the dropdown, make sure it's fully visible
                if (this.dropdownContent.classList.contains('open')) {
                    // Ensure dropdown is fully rendered
                    this.dropdownContent.style.display = 'flex';
                    this.dropdownContent.style.opacity = '1';
                    this.dropdownContent.style.transform = 'translateY(0)';
                }
            }, 0);
        }

        toggleHelpTooltip() {
            // Force render before toggling to ensure proper display
            setTimeout(() => {
                this.helpTooltip.classList.toggle('visible');
            }, 0);
        }

        addMessage(text, sender = 'user') {
            const activeConversation = this.getActiveConversation();
            if (!activeConversation) return;

            const newMsg = {
                sender,
                text,
                time: this.getCurrentTime(),
                date: this.getCurrentDate(),
                feedback: null
            };

            activeConversation.messages.push(newMsg);

            // If it's a new conversation with just the initial message, update the title based on first user message
            if (activeConversation.title === 'New Conversation' && activeConversation.messages.length === 2 && sender === 'user') {
                // Take first 15 chars for title
                activeConversation.title = text.length > 15 ? text.substring(0, 15) + '...' : text;
                this.updateDropdownContent();
            }

            this.updateMessages();

            // Add animation class to newest message
            const messageElements = this.chatBody.querySelectorAll('.ai-chatbot-message');
            if (messageElements.length > 0) {
                const newestMessage = messageElements[messageElements.length - 1];
                newestMessage.classList.add('new-message');
            }

            // If it's a user message, simulate a bot response
            if (sender === 'user') {
                setTimeout(async () => {
                    // Generate different responses based on conversation context

                    // getResponse(text)
                    let botResponse = await this.getResponse(text);

                    if (text.toLowerCase().includes("payment") || text.toLowerCase().includes("vendor")) {
                        botResponse = "I'll check the vendor payment status for you. Could you provide the vendor ID or name?";
                    } else if (text.toLowerCase().includes("order") || text.toLowerCase().includes("ope")) {
                        botResponse = "I can help with your order issue. To proceed, I'll need the order number and details about what's wrong.";
                    } else if (text.toLowerCase().includes("status") || text.toLowerCase().includes("update")) {
                        botResponse = "I'll get you a status update right away. Could you confirm which transaction you're inquiring about?";
                    } else if (text.toLowerCase().includes("add") || text.toLowerCase().includes("database")) {
                        botResponse = "I can help you add that to the database. What specific information do you need to add?";
                    } else if (text.toLowerCase().includes("help") || text.toLowerCase().includes("how")) {
                        botResponse = "I'm happy to help! Could you provide more details about what you're trying to accomplish?";
                    }

                    this.addMessage(botResponse, 'bot');
                }, 1000);
            }
        }

        createNewConversation() {
            // Immediately close dropdown for better UX
            this.hideDropdown();

            // Create new conversation with current timestamp
            const newId = this.generateId();
            const currentTime = this.getCurrentTime();
            const currentDate = this.getCurrentDate();

            const newConversation = {
                id: newId,
                title: 'New Conversation',
                startTime: currentTime,
                startDate: currentDate,
                messages: [
                    {
                        sender: 'bot',
                        text: this.options.initialMessage,
                        time: currentTime,
                        date: currentDate,
                        feedback: null
                    }
                ]
            };

            // Always create a new conversation
            this.conversations.unshift(newConversation);

            // Set as active conversation
            this.activeConversationId = newId;

            // Update UI immediately
            this.updateDropdownContent();
            this.updateMessages();

            // Focus input field
            setTimeout(() => {
                this.messageInput.focus();
            }, 50);

            console.log('New conversation created:', newId);
        }

        // Function to explicitly hide dropdown
        hideDropdown() {
            this.dropdownContent.classList.remove('open');
            // Ensure the display and opacity are set correctly
            setTimeout(() => {
                if (!this.dropdownContent.classList.contains('open')) {
                    this.dropdownContent.style.display = 'none';
                    this.dropdownContent.style.opacity = '0';
                }
            }, 200);
        }

        setFeedback(messageIndex, type) {
            const activeConversation = this.getActiveConversation();
            if (!activeConversation || !activeConversation.messages[messageIndex]) return;

            // If clicking the same feedback that's already active, toggle it off
            if (activeConversation.messages[messageIndex].feedback === type) {
                activeConversation.messages[messageIndex].feedback = null;
            } else {
                activeConversation.messages[messageIndex].feedback = type;
            }

            this.updateMessages();
        }

        bindEvents() {
            // Widget button click
            this.widgetButton.addEventListener('click', () => {
                this.toggleChatWindow();
            });

            // Close button click
            this.closeButton.addEventListener('click', () => {
                this.toggleChatWindow();
            });

            // Help button click
            this.helpButton.addEventListener('click', (e) => {
                e.stopPropagation();
                this.toggleHelpTooltip();
            });

            // Hide tooltip when clicking elsewhere
            document.addEventListener('click', (e) => {
                if (this.helpTooltip && this.helpTooltip.classList.contains('visible') &&
                    !e.target.closest('.ai-chatbot-help')) {
                    this.helpTooltip.classList.remove('visible');
                }
            });

            // Dropdown button click
            this.dropdownButton.addEventListener('click', (e) => {
                e.stopPropagation();
                this.toggleDropdown();
            });

            // Bind new conversation button
            this.bindNewConversationEvent();

            // Send button click
            this.sendButton.addEventListener('click', () => {
                const text = this.messageInput.value.trim();
                if (text) {
                    this.addMessage(text);
                    this.messageInput.value = '';
                }
            });

            // Input keypress (Enter)
            this.messageInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    const text = this.messageInput.value.trim();
                    if (text) {
                        this.addMessage(text);
                        this.messageInput.value = '';
                    }
                }
            });

            // Close dropdown when clicking outside
            document.addEventListener('click', (e) => {
                if (this.dropdownContent.classList.contains('open') &&
                    !e.target.closest('.ai-chatbot-dropdown')) {
                    this.hideDropdown();
                }
            });

            this.bindDropdownItemEvents();
            this.bindFeedbackEvents();
        }

        bindNewConversationEvent() {
            // Find and rebind the new conversation button
            const newConversationBtn = this.chatWindow.querySelector('.ai-new-conversation');
            if (newConversationBtn) {
                // Remove any existing event listeners first
                const newElement = newConversationBtn.cloneNode(true);
                newConversationBtn.parentNode.replaceChild(newElement, newConversationBtn);

                // Add the event listener to the new element
                newElement.addEventListener('click', (e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    // Add visual feedback
                    newElement.style.backgroundColor = '#EEF3FF';
                    setTimeout(() => {
                        newElement.style.backgroundColor = '';
                        this.createNewConversation();
                    }, 100);
                });
            }
        }

        bindDropdownItemEvents() {
            const items = this.chatWindow.querySelectorAll('.ai-chatbot-dropdown-item');
            items.forEach(item => {
                item.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const id = item.getAttribute('data-id');
                    // Add visual feedback
                    item.style.backgroundColor = '#EEF3FF';
                    setTimeout(() => {
                        item.style.backgroundColor = '';
                        this.activeConversationId = id;
                        // Hide dropdown properly
                        this.hideDropdown();
                        this.updateDropdownContent();
                        this.updateMessages();
                    }, 100);
                });
            });
        }

        bindFeedbackEvents() {
            const feedbackButtons = this.chatWindow.querySelectorAll('.ai-chatbot-feedback-button');
            feedbackButtons.forEach(button => {
                button.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const messageIndex = parseInt(button.getAttribute('data-index'));
                    const isPositive = button.classList.contains('positive');
                    this.setFeedback(messageIndex, isPositive ? 'positive' : 'negative');
                });
            });
        }
    }

    // Make it available globally
    window.ChatbotWidget = ChatbotWidget;

    // Auto-initialize if data attribute exists
    document.addEventListener('DOMContentLoaded', () => {
        if (document.querySelector('[data-chatbot-auto]')) {
            new ChatbotWidget();
        }
    });
})();

// Usage:
// 1. Include this script in your HTML
// 2. Initialize the widget with: new ChatbotWidget();
// 3. Or add data-chatbot-auto attribute to any element to auto-initialize
  
