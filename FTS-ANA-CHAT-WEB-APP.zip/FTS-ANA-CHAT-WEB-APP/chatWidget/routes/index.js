var express = require('express');
var router = express.Router();


var foo = require("../global");
// import globalVars from "../../global";
// global.apimKey = undefined;
console.log('asdasdasd ' + foo.apimKey);

// global = foo.apimKey

/* GET home page. */
router.get('/home', function(req, res, next) {
  res.render('index', { title: 'Welcome to the Anna Chatbot', apimKey: foo.apimKey });
});

module.exports = router;



